import { AuthRequest } from './auth-request';

describe('AuthRequest', () => {
  it('should create an instance', () => {
    expect(new AuthRequest()).toBeTruthy();
  });
});
