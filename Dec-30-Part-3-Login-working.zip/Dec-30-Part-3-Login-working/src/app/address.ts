export class Address {
    public addressId : number;
    public street : string;
    public doorno : string;
    public city : string;
    constructor() {
        
    }
}
