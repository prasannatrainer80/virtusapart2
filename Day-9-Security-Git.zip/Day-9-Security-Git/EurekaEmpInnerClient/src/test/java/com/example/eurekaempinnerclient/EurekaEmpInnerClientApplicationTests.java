package com.example.eurekaempinnerclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaEmpInnerClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
