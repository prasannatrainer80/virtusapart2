package com.example.model;

public enum OrderStatus {
	PENDING, ACCEPTED, DENIED
}
