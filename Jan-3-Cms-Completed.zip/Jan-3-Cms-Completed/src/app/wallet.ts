export class Wallet {
    public walId : number;
    public cusId : number;
    public walAmount : number;
    public walSource :string;
    constructor() {

    }

}
