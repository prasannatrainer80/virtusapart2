package org.example;

public class Customer {

  private int id;
  private String customerName;
  private String city;
  private double premium;

  // Add 10 records of customer to TreeSet
  // Sort By City First, in City if any duplicates sort by customerName wise
}
