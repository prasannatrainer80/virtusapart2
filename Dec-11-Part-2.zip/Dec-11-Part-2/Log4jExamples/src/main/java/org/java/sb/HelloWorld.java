package org.java.sb;

import org.apache.log4j.Logger;

public class HelloWorld {

  private static Logger logger = Logger.getLogger(HelloWorld.class);
  public static void main(String[] args) {
    logger.info("Welcome to Log4j..!");
    logger.info("Thank You All...Virtusa Team");
    System.out.println("Hello World");
  }
}
