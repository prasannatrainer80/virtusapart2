package com.example.ep;

public class CheckEmployServiceStatus {

    public static boolean checkEmployServiceStatus(){
        return false;
    }
}
