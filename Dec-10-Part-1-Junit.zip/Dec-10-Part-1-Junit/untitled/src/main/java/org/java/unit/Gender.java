package org.java.unit;

public enum Gender {
  MALE, FEMALE
}
