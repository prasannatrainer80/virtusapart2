"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Agent_1 = require("./Agent");
var obj = new Agent_1.Agent({ city: "Hyderabad", state: "TS", firstName: "Prasanna", lastName: "Pappu" });
obj.show();
