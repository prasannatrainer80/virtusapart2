"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Crocodile_1 = require("./Crocodile");
var cr1 = new Crocodile_1.Crocodile("Crocodile", 12, "Wild Category...");
console.log(cr1.toString());
