var studentName = "Keshav";
var age = 22;
var isActive = true;
console.log("Student Name " + studentName);
console.log("Age  " + age);
console.log("Status  " + isActive);
