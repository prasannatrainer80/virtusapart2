import { Crocodile } from "./Crocodile";

let cr1 = new Crocodile("Crocodile",12,"Wild Category...");
console.log(cr1.toString());