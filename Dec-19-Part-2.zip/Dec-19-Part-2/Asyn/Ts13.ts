import { Student } from "./Student";

const student1 = new Student();
student1.sno = 1;
student1.name = "Lokesh";
student1.city = "Pune";
student1.cgp = 8.8;

console.log("Student No  " +student1.sno);
console.log("Student Name " +student1.name);
console.log("City  " +student1.city);
console.log("Cgp  " +student1.cgp);