import { Person } from "./Person";

let person1 = new Person("Islam",22);
console.log(person1.show());