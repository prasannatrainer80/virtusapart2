var counter = 22;
// counter = "Welcome";
var names = [
    "Lokesh", "Harsh Naidu",
    "Ankit", "Bharathi", "Anusri",
    "Shaili"
];
names.forEach(function (x) { return console.log(x); });
