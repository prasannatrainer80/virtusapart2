var sayHello = function () {
    return "Welcome to React Programming...Thank You...";
};
console.log(sayHello());
