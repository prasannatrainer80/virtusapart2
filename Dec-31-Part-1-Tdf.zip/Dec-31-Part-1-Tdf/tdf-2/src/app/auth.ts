export class Auth {
    public username : string;
    public passcode : string;
    constructor() {
        
    }
}
