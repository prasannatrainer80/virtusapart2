import { Auth } from './auth';

describe('Auth', () => {
  it('should create an instance', () => {
    expect(new Auth()).toBeTruthy();
  });
});
