export class Login {
    public username : string;
    public passcode : string;
    constructor() {

    }
}
