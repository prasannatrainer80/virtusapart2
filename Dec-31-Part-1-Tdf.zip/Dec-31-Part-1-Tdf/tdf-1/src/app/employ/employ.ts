import { Component } from '@angular/core';

@Component({
  selector: 'app-employ',
  imports: [],
  templateUrl: './employ.html',
  styleUrl: './employ.css',
})
export class Employ {

}
