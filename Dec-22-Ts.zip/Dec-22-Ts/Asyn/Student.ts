export class Student {
    public sno : number;
    public name : string;
    public city : string;
    public cgp : number;
    public stream ?: string;
    constructor() {
        
    }
}