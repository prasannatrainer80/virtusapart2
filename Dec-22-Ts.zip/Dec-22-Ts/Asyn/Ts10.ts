const sum = (a : number, b : number) : number => a + b;

const sub = (a : number, b : number) : number => a - b; 

const mult = (a : number, b : number) : number => a * b;

console.log("Sum is  " +sum(12,5));
console.log("Sub is  " +sub(12,5));
console.log("Mult is " +mult(12,5));