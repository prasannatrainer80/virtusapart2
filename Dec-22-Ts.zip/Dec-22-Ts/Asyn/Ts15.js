"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Person_1 = require("./Person");
var person1 = new Person_1.Person("Islam", 22);
console.log(person1.show());
