import { Vendor } from "./Vendor";

var obj1 = new Vendor("Zomoto",8843.22);
console.log(obj1.toString());
