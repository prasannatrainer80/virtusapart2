import { Harsh } from "./Harsh";
import { Lokesh } from "./Lokesh";

var obj1 = new Harsh();
obj1.name();
obj1.email();

var obj2 = new Lokesh();
obj2.name();
obj2.email();