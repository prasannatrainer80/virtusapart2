var item1 = {
    id: 1,
    name: "Laptop",
    price: 99423
};
console.log(" Item Id ".concat(item1.id, "  Item Name ").concat(item1.name, " \n    Price ").concat(item1.price, " Description ").concat(item1.description, " "));
