"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Training = void 0;
var Training = /** @class */ (function () {
    function Training() {
    }
    return Training;
}());
exports.Training = Training;
