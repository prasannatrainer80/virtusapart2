import { Training } from "./AbsEx1";

export class Lokesh extends Training {
    name(): void {
        console.log("Name is Lokesh...");
    }
    email(): void {
        console.log("Email is Lokesh@gmail.com");
    }
    
}