export abstract class Training {
    abstract name() : void;
    abstract email() : void;
}

