import { Training } from "./AbsEx1";

export class Harsh extends Training {
    name(): void {
        console.log("Name is Harsh...");
    }
    email(): void {
        console.log("Email is harsh@gmail.com");
    }
    
}