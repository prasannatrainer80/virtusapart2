import { Animal } from "./Animal";

export class Crocodile extends Animal {
    constructor(name : string, age : number,species : string) {
        super(name,age,species);
    }
}