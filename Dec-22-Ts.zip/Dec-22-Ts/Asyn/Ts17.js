"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Vendor_1 = require("./Vendor");
var obj1 = new Vendor_1.Vendor("Zomoto", 8843.22);
console.log(obj1.toString());
