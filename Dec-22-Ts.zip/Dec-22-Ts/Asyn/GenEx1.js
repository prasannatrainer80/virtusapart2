function show(parameter) {
    return parameter;
}
var res1 = show("Welcome to Typescript Generics...");
var res2 = show(21);
var res3 = show(true);
console.log(res1);
console.log(res2);
console.log(res3);
