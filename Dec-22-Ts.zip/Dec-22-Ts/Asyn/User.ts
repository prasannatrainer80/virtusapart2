export class User {
    public userName ?: string;
    public passCode ?: string;
    public utype : string;
    constructor() {

    }
}