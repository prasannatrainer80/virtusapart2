function show(t, v) {
    return [t, v];
}
var obj1 = show(1, "Prasanna");
var obj2 = show("Raj", true);
var obj3 = show("Majesh", 84245.22);
console.log(obj1);
console.log(obj2);
console.log(obj3);
