let counter : number = 22 
// counter = "Welcome";
let names : string[] =
[
   "Lokesh","Harsh Naidu",
   "Ankit","Bharathi","Anusri",
   "Shaili"
]

names.forEach(x => console.log(x));