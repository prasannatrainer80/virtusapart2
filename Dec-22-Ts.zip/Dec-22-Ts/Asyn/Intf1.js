var data1 = {
    studentname: "Rajesh",
    email: "Rajesh@gmail.com"
};
console.log("Student Name  ".concat(data1.studentname, ", Email : ").concat(data1.email, " "));
