package com.example.eurekanew;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaNewApplicationTests {

    @Test
    void contextLoads() {
    }

}
