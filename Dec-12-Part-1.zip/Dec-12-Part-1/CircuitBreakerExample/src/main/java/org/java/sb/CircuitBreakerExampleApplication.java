package org.java.sb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CircuitBreakerExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(CircuitBreakerExampleApplication.class, args);
    }

}
