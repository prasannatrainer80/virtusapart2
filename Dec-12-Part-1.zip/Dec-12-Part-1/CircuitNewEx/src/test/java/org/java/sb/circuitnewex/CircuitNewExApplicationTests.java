package org.java.sb.circuitnewex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CircuitNewExApplicationTests {

    @Test
    void contextLoads() {
    }

}
