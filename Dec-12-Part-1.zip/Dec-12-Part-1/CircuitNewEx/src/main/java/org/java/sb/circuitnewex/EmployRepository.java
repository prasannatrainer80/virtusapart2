package org.java.sb.circuitnewex;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployRepository extends JpaRepository<Employ,Long> {

}
