import { Component } from '@angular/core';

@Component({
  selector: 'app-menu-show',
  imports: [],
  templateUrl: './menu-show.html',
  styleUrl: './menu-show.css',
})
export class MenuShow {

}
