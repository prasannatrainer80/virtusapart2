package com.example.webclientex1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebClientEx1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
