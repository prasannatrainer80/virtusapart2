package com.example.webclientex1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebClientEx1Application {

    public static void main(String[] args) {
        SpringApplication.run(WebClientEx1Application.class, args);
    }

}
