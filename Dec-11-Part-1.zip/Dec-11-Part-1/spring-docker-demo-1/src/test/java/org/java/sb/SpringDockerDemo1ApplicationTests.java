package org.java.sb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDockerDemo1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
