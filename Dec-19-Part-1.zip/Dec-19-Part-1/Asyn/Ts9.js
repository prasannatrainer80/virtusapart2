function sum(a, b) {
    return a + b;
}
function sub(a, b) {
    return a - b;
}
function mult(a, b) {
    return a * b;
}
console.log("Sum is  " + sum(12, 5));
console.log("Sub is  " + sub(12, 5));
console.log("Mult is  " + mult(12, 5));
