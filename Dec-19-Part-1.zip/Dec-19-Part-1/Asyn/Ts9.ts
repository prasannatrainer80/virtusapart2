function sum(a : number, b : number) : number {
    return a + b;
}

function sub(a:number, b : number) : number {
    return a - b;
}

function mult(a : number, b : number) : number {
    return a * b;
}

console.log("Sum is  " +sum(12,5));
console.log("Sub is  " +sub(12,5));
console.log("Mult is  " +mult(12,5));