import { Agent } from "./Agent";

var obj = new Agent({city:"Hyderabad",state:"TS",firstName:"Prasanna",lastName:"Pappu"});
obj.show();