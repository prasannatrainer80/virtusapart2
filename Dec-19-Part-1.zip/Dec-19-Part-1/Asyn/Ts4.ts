let employ : {
    empno : number;
    name : string;
    salary : number;
}

employ = {
    empno :1,
    name : "Lokesh",
    salary : 88323
}

console.log("Employ No  " +employ.empno + " Employ Name " +employ.name 
    + " Salary  " +employ.salary);

