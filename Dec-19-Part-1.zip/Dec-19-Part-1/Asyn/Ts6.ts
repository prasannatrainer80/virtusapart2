let e1 : any = {empno : 1,nam : "Raj", salary : 82822};
console.log(e1.empno);
console.log(e1.nam);
console.log(e1.salary);

let e2 : any = "Prasanna";
console.log(e2);

let e3 : any = 82344;
console.log(e3);